This server contains marine environmental monitoring data delivered to the Swedish National data host for oceanographic and marine biological environmental data.

The files follow a structure according to:
Monitoring year/Data type/Data deliverer (following RLABO codes; see SMHIs code list)/Version number (using date).

This data package contains zooplankton data.

Investigation type: Samples are collected by dragging plankton nets vertically through the water. The volume of the sample is estimated either using a volume counter connected to the net or by approximate the volume by multiplying area of the upper net opening and the sampled depth. The collected organisms are preserved for later counting and size determination. Sometimes only a partial sample is analyzed, due to large amount of animals, and the results are extrapolated the entire container. If possible, the observations consider the stage of development and sex of each species, the number of animals per sample and per water volume, weight and mean or median length. More information is available in Swedish at https://www.havochvatten.se/hav/vagledning--lagar/vagledningar/ovriga-vagledningar/undersokningstyper-for-miljoovervakning/.

Data packages are compressed to zip-format.

The zip-file contains:

- File "README.txt": Describes in English the contents of the zip-file and the terms of use.

- File "README_sv.txt": Describes in Swedish the contents of the zip-file and the terms of use.

- File "shark_metadata.txt": Created by the Swedish National data host with an overview and description of the delivered dataset.

- Folder "processed_data": Contains one or multiple edited data files (e.g. semi-colon separated csv-, txt- or xlm-format), with corrected data (e.g. corrected codes, species, and station name) and adapted to the SHARK data handling system, a delivery_note.txt where the provider of the data describes the content of the delivered data and sometimes a change_log.txt file that specifies changes made by the Swedish National data host in the data review process.

- Folder "received_data": Contains one or multiple original data files from the data deliverer (e.g. semi-colon delimited, tab-delimited or xml files), followed by supplementary files from the data deliverer with relevant information for the delivered data (in different formats such as pdf).

- Folder "shark_generated": Contains a shark_data.txt file that shows the published data in a table with translated column names, a shark_column_data.txt with data organized in a table with one row per sample, a shark_metadata_auto.txt with detailed information of the data set (e.g. minimum and maximum latitude or the units of measurements) and a shark_translate.txt with translations for codes used in the data table.


Data is free to use according to the data policy described in "Terms of download"-link at the bottom of the SHARKweb page (https://sharkweb.smhi.se/).

Contact shark@smhi.se if you have any questions or comments.

At https://www.smhi.se/klimatdata/oceanografi/havsmiljodata you can find the species list for different years and a guide for reporting of data, in which can you find code descriptions used by the Swedish National data host.