Denna server inneh�ller marin milj��vervakningsdata som levererats till datav�rden SMHI.

Filerna �r ordnade efter �vervaknings�r/Datatyp/Dataleverant�r (enligt RLABO-koder; se SMHIs kodlista)/Versionsnummer enligt datum. 

Detta datapaket inneh�ller v�xtplankton data.

Unders�kningstyp: V�xtplankton/picoplankton prov tas oftast med en vattenh�mtare p� ett visst djup eller med en slang som h�ngs vertikalt i vattnet och sedan f�rsluts f�r att h�mta en blandning av vatten fr�n olika djup (ett s.k. integrerat prov). Samlade v�xtplankton/picoplankton konserveras f�r att senare artbest�mmas, r�knas och storleksbest�mmas. F�r varje art (som ibland blir best�md till storleksklass samt trofisk status i enlighet med HELCOMs PEG-lista) presenteras data �ver antal r�knade individer per provet, antal alger per vattenvolym, vikten och cellvolymen per vattenvolym. B�de prokaryota och eukaryota v�xtplankton rapporteras och vissa m�tningar fokuserar specifikt p� picoplankton. F�r detaljerad information l�s vidare vid https://www.havochvatten.se/hav/vagledning--lagar/vagledningar/ovriga-vagledningar/undersokningstyper-for-miljoovervakning/.

Datapaket �r komprimerade i zip-format.

Zip-filen inneh�ller:

- Filen "README.txt": Beskriver p� engelska inneh�llet i zip-filen samt anv�ndarvillkor f�r data.

- Filen "README_sv.txt": Beskriver p� svenska inneh�llet i zip-filen samt anv�ndarvillkor f�r data.

- Filen "shark_metadata.txt": Skapad av datav�rden med en allm�n beskrivning av levererade data.

- Mappen "processed_data": Inneh�ller en eller flera redigerade datafiler (kan vara semikolonseparerat, tabbavgr�nsade eller xml filer), som �r korrigerad (t.ex. koder, arter och stationsnamn) och anpassad till SHARKs datahanteringssystem, en delivery_note.txt d�r dataleverant�ren visar vad dataleveransen inneh�ller, en analyse_info.txt d�r information om analyserna presenteras, en sampling_info.txt d�r information om provtagningen presenteras och ibland en change_log.txt fil som dokumenterar f�r�ndringar gjorda av datav�rden under leveranskontroll och databearbetning.

- Mappen "received_data": Inneh�ller en eller flera levererade datafiler fr�n dataleverant�ren (kan vara semikolonseparerat, tabbavgr�nsade, excel-filer eller xml filer), samt medf�ljande filer fr�n leverant�ren (i olika format som t.ex. pdf) som anses vara relevant tillsammans med levererade data.

- Mappen "shark_generated": Inneh�ller shark_data.txt som visar bearbetad data med �vers�tta kolumnkoder, en shark_column_data.txt med data organiserad i en tabell med en rad per prov, en shark_metadata_auto.txt med detaljerad information om data (t.ex. minimum och maximum latitud samt enheter) och en shark_translate.txt som inneh�ller �vers�ttningar f�r koder anv�nda i data. 


Data �r fria att anv�ndas enligt den datapolicy/anv�ndarvillkor som beskrivs i l�nken "Villkor f�r nedladdning" l�ngst ned p� sidan f�r SHARKweb (https://sharkweb.smhi.se/).

Kontakta shark@smhi.se om du har fr�gor eller kommentarer.

P� hemsidan https://www.smhi.se/klimatdata/oceanografi/havsmiljodata finns artlistor f�r olika �r och en v�gledning f�r datarapportering d�r man bland annat hittar kodlistor som beskriver de koder som anv�nds inom datav�rdskapet.